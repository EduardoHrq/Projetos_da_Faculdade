/*
Eduardo henrique Lima Silva - 0015751
Henrique Bitencourt Oliveira
*/

package Faculdade;

public class Executavel {
    public static void main(String[] args){
        Universidade system = new Universidade();
        system.menu();
    }

}
